# WinDivert capture experiment

This is the second capture POC. It tests the same UDP knock visibility as the Winsock probe, using WinDivert's supplied signed driver. Authentication and temporary access grants remain part of the later SPA design.

## Run on the Windows Server 2019 receiver

Extract `dist/zeitgeist-windivert-poc.zip`. Open **PowerShell as Administrator** in the extracted project directory containing `dist` and `poc`. Keep `windivert-capture.exe`, `WinDivert.dll`, and `WinDivert64.sys` together in `dist`.

Using the adapter address from your previous test:

```powershell
.\dist\windivert-capture.exe 10.2.2.194 --seconds 60 | Tee-Object capture-windivert.txt
```

Wait for `READY`, then send from the other machine. Keep Windows Firewall enabled and do not add an inbound allow rule. Running the probe loads the bundled WinDivert driver on demand. It does not edit firewall rules or bind a TCP/UDP port.

The capture filter is printed at startup:

```text
inbound and ip and udp and ip.DstAddr == 10.2.2.194
```

There is no destination-port restriction. This POC uses IPv4 and the supplied local address; a wrong address will match no packets. `--seconds` accepts 1 through 3600 and defaults to 60. Ctrl+C stops early. Idle capture also stops at its deadline.

## Send from Kali

Use the same command as before, while the receiver shows `READY`:

```bash
for probe_port in 41001 42555 49999; do
    printf 'ZEITGEIST-POC: port=%s seq=1\n' "$probe_port" | nc -u -w 1 10.2.2.194 "$probe_port"
done
```

Alternatively, from a second Windows machine:

```powershell
.\poc\send-probe.ps1 -Target 10.2.2.194
```

The PowerShell sender sends nine datagrams by default; the Kali command sends three. Sending successfully does not confirm delivery.

## Expected output and interpretation

Example; sender address, source port, and interface index vary:

```text
MARKER 10.2.2.100:53123 -> 10.2.2.194:41001 ifidx=4 bytes=31 payload="ZEITGEIST-POC: port=41001 seq=1\x0a"
SUMMARY received=3 complete_udp=3 markers=3 malformed_or_unexpected=0
```

`STATUS` prints every ten seconds. `received` counts packets returned by the already-filtered WinDivert handle. `complete_udp` counts parsed, length-checked UDP datagrams, and `markers` counts payloads starting with `ZEITGEIST-POC:`. These counts have a narrower scope than the Winsock probe's raw `received` count.

Add `--all-udp` to print other UDP payloads matching the filter. Output escapes control characters and displays at most 256 payload bytes. A zero exit code means capture finished normally, even with zero markers. Startup/receive errors produce a nonzero exit code.

**Matching payloads together with matching Windows Firewall `DROP UDP` records are the useful result.** Seeing a marker alone confirms capture, but does not establish that Windows Firewall blocked that packet. No marker and no independent arrival evidence remains inconclusive.

For the stronger test, follow [the scoped block and logging steps](firewall-test.md), replacing the example receiver with `10.2.2.194` and the sender with your Kali source address as seen by Windows. Run the WinDivert command in that guide, resend the same probes, then perform the documented cleanup. No need to disable Windows Firewall.

Send back `capture-windivert.txt`, any matching drop records, and any error output. The raw Winsock probe remains included for comparison.

## Startup problems

| Error | What to check |
| --- | --- |
| Missing `WinDivert.dll` before startup | Extract the entire package; keep the DLL beside the executable. |
| `WinDivertOpen` error 2 | Keep the supplied `WinDivert64.sys` in the same directory. |
| Error 5 | Use an elevated Administrator terminal. |
| Error 577 | Windows rejected the driver signature. Report the error and security configuration. |
| Error 1275 | Driver loading was blocked. Report the security software/VM configuration. |
| Error 654 | An incompatible WinDivert version is already loaded; report the error before changing other applications. |
| Error 1753 | The Base Filtering Engine service is unavailable. |

This package uses passive `WINDIVERT_FLAG_SNIFF | WINDIVERT_FLAG_RECV_ONLY` at `WINDIVERT_LAYER_NETWORK`. It neither reinjects nor intentionally drops traffic. Earlier filters, upstream devices, and the target configuration can still affect visibility; the Windows experiment is what determines suitability.

## Build from source

The package includes the original WinDivert release archive and upstream source archive under `third_party/windivert`, along with the license. With CMake and Visual Studio C++ build tools, from the project root:

```powershell
Expand-Archive .\third_party\windivert\WinDivert-2.2.2-A.zip -DestinationPath .\build\deps -Force
$winDivertRoot = (Resolve-Path .\build\deps\WinDivert-2.2.2-A).Path
cmake -S poc -B build\windivert -A x64 "-DWINDIVERT_ROOT=$winDivertRoot"
cmake --build build\windivert --config Release
.\build\windivert\Release\windivert-capture.exe 10.2.2.194 --seconds 60
```

CMake copies the official DLL and driver beside the built executable. Both probes are built when `WINDIVERT_ROOT` is supplied; omitting it still builds the original raw Winsock probe alone. WinDivert is linked dynamically. The packaged probe's GCC C++ runtime is statically linked.

The project was cross-compiled on Linux. That verifies the Windows build, but does not establish that the driver loads or captures blocked traffic on your server.

References: [WinDivert API and deployment](https://reqrypt.org/windivert-doc.html), [official release](https://github.com/basil00/WinDivert/releases/tag/v2.2.2), [third-party notices](../THIRD-PARTY-NOTICES.md), [larger design checkpoint](../docs/brainstorming-checkpoint.md).
