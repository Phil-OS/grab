// Throwaway passive WinDivert capture probe; no TCP/UDP listener or firewall grants.
#ifndef _WIN32
#error This probe requires Windows.
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

// Include the C++ headers before WinDivert's legacy SAL compatibility macros.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>

#include <windows.h>
#include <windivert.h>

namespace {
constexpr std::string_view marker = "ZEITGEIST-POC:";
volatile LONG stop_requested = FALSE;

BOOL WINAPI on_console_event(DWORD event) {
    if (event == CTRL_C_EVENT || event == CTRL_BREAK_EVENT) {
        InterlockedExchange(&stop_requested, TRUE);
        return TRUE;
    }
    return FALSE;
}

std::string windows_error(const char* operation, DWORD code) {
    char text[512]{};
    FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                   nullptr, code, 0, text, static_cast<DWORD>(sizeof(text)), nullptr);
    std::string description(text);
    while (!description.empty() &&
           (description.back() == '\r' || description.back() == '\n')) {
        description.pop_back();
    }
    std::string message = std::string(operation) + " failed: " +
                          std::to_string(code) + " " + description;
    switch (code) {
    case ERROR_ACCESS_DENIED:
        message += " (Run PowerShell as Administrator.)";
        break;
    case ERROR_FILE_NOT_FOUND:
        message += " (Keep the supplied WinDivert64.sys beside WinDivert.dll and the EXE.)";
        break;
    case ERROR_INVALID_IMAGE_HASH:
        message += " (Windows rejected the driver signature; report this error.)";
        break;
    case ERROR_DRIVER_BLOCKED:
        message += " (Driver loading was blocked; report the security/VM configuration.)";
        break;
    default:
        break;
    }
    return message;
}

struct Options {
    std::string local_ip;
    int seconds = 60;
    bool all_udp = false;
};

void usage() {
    std::cout <<
        "Usage: windivert-capture.exe LOCAL_IPV4 [--seconds 60] [--all-udp]\n"
        "Run as Administrator. Keep the supplied WinDivert.dll and WinDivert64.sys\n"
        "beside the EXE. WinDivert loads its signed driver on demand.\n"
        "Captures inbound IPv4 UDP to LOCAL_IPV4 across all destination ports.\n"
        "Default: print payloads beginning ZEITGEIST-POC:. --all-udp prints all UDP.\n"
        "Passive SNIFF + RECV_ONLY mode. No TCP/UDP listener or firewall rule edits.\n"
        "Stops after the duration or Ctrl+C, including when no packets arrive.\n";
}

Options parse_options(int argc, char** argv) {
    Options options;
    UINT32 address = 0;
    if (!WinDivertHelperParseIPv4Address(argv[1], &address) || address == 0 ||
        address == 0xFFFFFFFFU || (address >> 28) >= 14 || (address >> 24) == 127) {
        throw std::invalid_argument("Supply the receiver adapter's unicast IPv4 address");
    }
    char canonical[16]{};
    if (!WinDivertHelperFormatIPv4Address(address, canonical, sizeof(canonical))) {
        throw std::runtime_error("Could not format the local IPv4 address");
    }
    options.local_ip = canonical;
    for (int index = 2; index < argc; ++index) {
        const std::string arg = argv[index];
        if (arg == "--all-udp") {
            options.all_udp = true;
        } else if (arg == "--seconds" && index + 1 < argc) {
            const std::string value = argv[++index];
            if (value.empty() || value.size() > 4 ||
                value.find_first_not_of("0123456789") != std::string::npos) {
                throw std::invalid_argument("--seconds must be 1 through 3600");
            }
            options.seconds = std::stoi(value);
            if (options.seconds < 1 || options.seconds > 3600) {
                throw std::invalid_argument("--seconds must be 1 through 3600");
            }
        } else {
            throw std::invalid_argument("Unknown option or missing value: " + arg);
        }
    }
    return options;
}

struct DivertHandle {
    HANDLE handle = INVALID_HANDLE_VALUE;
    explicit DivertHandle(const std::string& filter) {
        handle = WinDivertOpen(filter.c_str(), WINDIVERT_LAYER_NETWORK, 0,
                              WINDIVERT_FLAG_SNIFF | WINDIVERT_FLAG_RECV_ONLY);
        if (handle == INVALID_HANDLE_VALUE) {
            throw std::runtime_error(windows_error("WinDivertOpen", GetLastError()));
        }
    }
    ~DivertHandle() { WinDivertClose(handle); }
    DivertHandle(const DivertHandle&) = delete;
    DivertHandle& operator=(const DivertHandle&) = delete;
};

// One outstanding overlapped read permits status updates and an idle timeout.
// Cancellation is completed before the packet, address, and OVERLAPPED go away.
class PacketRead {
public:
    std::array<unsigned char, WINDIVERT_MTU_MAX> packet{};
    WINDIVERT_ADDRESS address{};
    DWORD length = 0;

    explicit PacketRead(HANDLE handle) : handle_(handle) {
        overlapped_.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (overlapped_.hEvent == nullptr) {
            throw std::runtime_error(windows_error("CreateEvent", GetLastError()));
        }
    }

    ~PacketRead() {
        if (pending_) {
            CancelIoEx(handle_, &overlapped_);
            DWORD ignored = 0;
            GetOverlappedResult(handle_, &overlapped_, &ignored, TRUE);
        }
        CloseHandle(overlapped_.hEvent);
    }

    PacketRead(const PacketRead&) = delete;
    PacketRead& operator=(const PacketRead&) = delete;

    void begin() {
        const HANDLE event = overlapped_.hEvent;
        overlapped_ = {};
        overlapped_.hEvent = event;
        if (!ResetEvent(event)) {
            throw std::runtime_error(windows_error("ResetEvent", GetLastError()));
        }
        address = {};
        address_length_ = sizeof(address);
        length = 0;
        if (!WinDivertRecvEx(handle_, packet.data(), static_cast<UINT>(packet.size()),
                             nullptr, 0, &address, &address_length_, &overlapped_)) {
            const DWORD code = GetLastError();
            if (code != ERROR_IO_PENDING) {
                throw std::runtime_error(windows_error("WinDivertRecvEx", code));
            }
        }
        pending_ = true;
    }

    bool poll() {
        const DWORD wait = WaitForSingleObject(overlapped_.hEvent, 250);
        if (wait == WAIT_TIMEOUT) {
            return false;
        }
        if (wait != WAIT_OBJECT_0) {
            throw std::runtime_error(windows_error("WaitForSingleObject", GetLastError()));
        }
        const BOOL result = GetOverlappedResult(handle_, &overlapped_, &length, FALSE);
        const DWORD code = result ? ERROR_SUCCESS : GetLastError();
        pending_ = false;
        if (!result) {
            throw std::runtime_error(windows_error("GetOverlappedResult", code));
        }
        return true;
    }

private:
    HANDLE handle_;
    OVERLAPPED overlapped_{};
    UINT address_length_ = 0;
    bool pending_ = false;
};

std::string escaped_payload(std::string_view payload) {
    std::ostringstream output;
    const auto length = std::min<std::size_t>(payload.size(), 256);
    for (std::size_t index = 0; index < length; ++index) {
        const auto byte = static_cast<unsigned char>(payload[index]);
        if (byte == '\\' || byte == '"') {
            output << '\\' << static_cast<char>(byte);
        } else if (byte >= 32 && byte <= 126) {
            output << static_cast<char>(byte);
        } else {
            output << "\\x" << std::hex << std::setw(2) << std::setfill('0')
                   << static_cast<unsigned>(byte);
        }
    }
    if (length < payload.size()) {
        output << "... [display truncated]";
    }
    return output.str();
}

std::string ipv4_text(UINT32 network_address) {
    char text[16]{};
    if (!WinDivertHelperFormatIPv4Address(WinDivertHelperNtohl(network_address),
                                         text, sizeof(text))) {
        throw std::runtime_error("Could not format a captured IPv4 address");
    }
    return text;
}

struct Counters {
    std::uint64_t received = 0;
    std::uint64_t complete_udp = 0;
    std::uint64_t markers = 0;
    std::uint64_t malformed = 0;
};

void print_stats(const Counters& counts, const char* label) {
    std::cout << label << " received=" << counts.received
              << " complete_udp=" << counts.complete_udp
              << " markers=" << counts.markers
              << " malformed_or_unexpected=" << counts.malformed << '\n';
}

void inspect_packet(const PacketRead& read, bool all_udp, Counters& counts) {
    ++counts.received;
    PWINDIVERT_IPHDR ip = nullptr;
    PWINDIVERT_UDPHDR udp = nullptr;
    PVOID data = nullptr;
    UINT available = 0;
    if (!WinDivertHelperParsePacket(read.packet.data(), read.length, &ip, nullptr,
                                    nullptr, nullptr, nullptr, nullptr, &udp,
                                    &data, &available, nullptr, nullptr) ||
        ip == nullptr || udp == nullptr || read.address.Outbound) {
        ++counts.malformed;
        return;
    }
    const std::size_t udp_length = WinDivertHelperNtohs(udp->Length);
    if (udp_length < sizeof(*udp) || udp_length - sizeof(*udp) > available ||
        (data == nullptr && udp_length > sizeof(*udp))) {
        ++counts.malformed;
        return;
    }
    const std::string_view payload(data == nullptr ? "" : static_cast<const char*>(data),
                                   udp_length - sizeof(*udp));
    ++counts.complete_udp;
    const bool matched = payload.size() >= marker.size() &&
                         payload.substr(0, marker.size()) == marker;
    if (matched) {
        ++counts.markers;
    }
    if (matched || all_udp) {
        std::cout << (matched ? "MARKER " : "UDP ")
                  << ipv4_text(ip->SrcAddr) << ':' << WinDivertHelperNtohs(udp->SrcPort)
                  << " -> " << ipv4_text(ip->DstAddr) << ':'
                  << WinDivertHelperNtohs(udp->DstPort)
                  << " ifidx=" << read.address.Network.IfIdx
                  << " bytes=" << payload.size()
                  << " payload=\"" << escaped_payload(payload) << "\"\n";
    }
}

int capture(const Options& options) {
    const std::string filter = "inbound and ip and udp and ip.DstAddr == " + options.local_ip;
    std::cout << "Zeitgeist WinDivert probe v1 (IPv4 only, WinDivert 2.2)\n"
              << "Filter: " << filter << '\n'
              << "Opening passive SNIFF | RECV_ONLY capture; the signed driver loads on demand.\n";
    DivertHandle divert(filter);
    PacketRead read(divert.handle);
    Counters counts;
    using Clock = std::chrono::steady_clock;
    const auto end = Clock::now() + std::chrono::seconds(options.seconds);
    auto next_status = Clock::now() + std::chrono::seconds(10);
    int exit_code = 0;
    try {
        read.begin();
        std::cout << "READY: send ZEITGEIST-POC: UDP payloads from ANOTHER machine to "
                  << options.local_ip << " on any destination port.\n"
                  << "Duration=" << options.seconds
                  << " seconds. No TCP/UDP listener. Firewall rules unchanged. Ctrl+C stops.\n";
        while (InterlockedCompareExchange(&stop_requested, FALSE, FALSE) == FALSE &&
               Clock::now() < end) {
            if (read.poll()) {
                inspect_packet(read, options.all_udp, counts);
                read.begin();
            }
            if (Clock::now() >= next_status) {
                print_stats(counts, "STATUS");
                next_status = Clock::now() + std::chrono::seconds(10);
            }
        }
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        exit_code = 1;
    }
    print_stats(counts, "SUMMARY");
    std::cout << "Correlate MARKER payloads with Windows Firewall DROP UDP records to\n"
              << "confirm visibility of blocked knocks. Zero markers alone is inconclusive.\n";
    return exit_code;
}
} // namespace

int main(int argc, char** argv) {
    std::cout << std::unitbuf;
    if (argc < 2 || std::string_view(argv[1]) == "--help" ||
        std::string_view(argv[1]) == "-h") {
        usage();
        return argc < 2 ? 2 : 0;
    }
    try {
        const auto options = parse_options(argc, argv);
        if (!SetConsoleCtrlHandler(on_console_event, TRUE)) {
            throw std::runtime_error(windows_error("SetConsoleCtrlHandler", GetLastError()));
        }
        return capture(options);
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 1;
    }
}
