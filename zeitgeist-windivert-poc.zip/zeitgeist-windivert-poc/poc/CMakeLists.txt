cmake_minimum_required(VERSION 3.15)
project(zeitgeist_capture_probes LANGUAGES CXX)

if(NOT WIN32)
    message(FATAL_ERROR "Use a Windows compiler or a Windows cross-compilation toolchain.")
endif()

add_executable(raw-capture raw_capture.cpp)
target_compile_features(raw-capture PRIVATE cxx_std_17)
target_link_libraries(raw-capture PRIVATE ws2_32)

set(probe_targets raw-capture)
set(WINDIVERT_ROOT "" CACHE PATH "Extracted official WinDivert distribution (with include and x64)")
if(WINDIVERT_ROOT)
    if(NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
        message(FATAL_ERROR "The WinDivert POC package targets Windows x64.")
    endif()
    foreach(required_file include/windivert.h x64/WinDivert.lib x64/WinDivert.dll x64/WinDivert64.sys)
        if(NOT EXISTS "${WINDIVERT_ROOT}/${required_file}")
            message(FATAL_ERROR "Missing ${WINDIVERT_ROOT}/${required_file}")
        endif()
    endforeach()
    add_library(WinDivert::WinDivert SHARED IMPORTED)
    set_target_properties(WinDivert::WinDivert PROPERTIES
        IMPORTED_IMPLIB "${WINDIVERT_ROOT}/x64/WinDivert.lib"
        IMPORTED_LOCATION "${WINDIVERT_ROOT}/x64/WinDivert.dll"
        INTERFACE_INCLUDE_DIRECTORIES "${WINDIVERT_ROOT}/include")
    add_executable(windivert-capture windivert_capture.cpp)
    target_compile_features(windivert-capture PRIVATE cxx_std_17)
    target_link_libraries(windivert-capture PRIVATE WinDivert::WinDivert)
    add_custom_command(TARGET windivert-capture POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            "${WINDIVERT_ROOT}/x64/WinDivert.dll" "$<TARGET_FILE_DIR:windivert-capture>"
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            "${WINDIVERT_ROOT}/x64/WinDivert64.sys" "$<TARGET_FILE_DIR:windivert-capture>")
    list(APPEND probe_targets windivert-capture)
endif()

foreach(probe IN LISTS probe_targets)
    if(MSVC)
        target_compile_options(${probe} PRIVATE /W4 /WX /EHsc)
        set_property(TARGET ${probe} PROPERTY
            MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    elseif(MINGW)
        target_compile_options(${probe} PRIVATE -Wall -Wextra -Wpedantic -Werror)
        target_link_options(${probe} PRIVATE -static -static-libgcc -static-libstdc++)
    endif()
endforeach()

if(NOT WINDIVERT_ROOT)
    message(STATUS "Set WINDIVERT_ROOT to build the optional WinDivert capture probe too.")
endif()
