# Raw Winsock capture experiment

Determine whether Windows delivers a complete UDP knock payload to a raw Winsock socket while Windows Firewall blocks the packet. This is a throwaway feasibility probe, not the SPA implementation.

The probe uses `AF_INET / SOCK_RAW / IPPROTO_IP` and `SIO_RCVALL`, binds only to an adapter's IPv4 address, and inspects inbound UDP across **all destination ports**. It installs no driver and makes no firewall changes. It does not bind a TCP/UDP port, send packets, authenticate knocks, or open ports.

Scope: Windows desktop/server, IPv4, one adapter per run. Tiny, unfragmented UDP probes only. IPv6, loopback, and capture across multiple adapters are outside this experiment.

## Run on the Windows receiver

Extract `dist/zeitgeist-winsock-poc.zip` on Windows, if using the packaged build. Run commands from the extracted project directory containing the top-level `README.md`, `dist`, and `poc`.

Open **PowerShell as Administrator**. Find the active physical/LAN adapter's address and record the environment:

```powershell
Get-NetIPAddress -AddressFamily IPv4 | Select-Object InterfaceAlias, IPAddress
Get-NetConnectionProfile | Select-Object InterfaceAlias, NetworkCategory
Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name, Enabled, DefaultInboundAction
Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber
```

Replace `192.168.1.40` with that adapter's actual IPv4 address. Start capture and wait for `READY` before sending:

```powershell
.\dist\raw-capture.exe 192.168.1.40 --seconds 60 --mode ip | Tee-Object capture-ip.txt
```

Keep Windows Firewall **enabled**. Start with unused test ports and do not create an inbound allow rule for the probe. If a firewall permission prompt appears, cancel it and record that fact. Test from another machine, preferably on the same LAN for this first experiment; sending from the receiver itself does not establish remote inbound visibility.

## Send from a second machine

With `nc` on Linux/macOS (one payload per port):

```bash
for probe_port in 41001 42555 49999; do
    printf 'ZEITGEIST-POC: port=%s seq=1\n' "$probe_port" | nc -u -w 1 10.2.2.194 "$probe_port"
done
```

Or with the included script on another Windows machine (three payloads per port, nine total):

```powershell
.\poc\send-probe.ps1 -Target 192.168.1.40
```

No elevation or separate sender binary is required for the PowerShell sender. It prints a run ID so you can correlate its payloads with the receiver. A successful UDP send is **not** a delivery confirmation.

## Repeat with the other capture mode

After the first run exits, run this on the receiver and send again from the second machine:

```powershell
.\dist\raw-capture.exe 192.168.1.40 --seconds 60 --mode on | Tee-Object capture-on.txt
```

`ip` selects `RCVALL_IPLEVEL`, without enabling NIC promiscuous mode. `on` selects `RCVALL_ON`, which can enable promiscuous mode. Both use the same raw socket and bind no transport port. Captured packets are filtered to the selected destination IPv4 address before displaying UDP payloads.

## Read the result

Example output; actual sender port and payload size will vary:

```text
MARKER 192.168.1.41:53123 -> 192.168.1.40:41001 bytes=31 payload="ZEITGEIST-POC: port=41001 seq=1\x0a"
```

The probe prints `STATUS` every ten seconds and `SUMMARY` at exit:

- `received`: raw datagrams delivered, including traffic later excluded by the probe.
- `inbound_ipv4`: complete IPv4 packets addressed to the chosen local IP.
- `complete_udp`: complete, unfragmented inbound UDP datagrams.
- `markers`: UDP payloads starting exactly with `ZEITGEIST-POC:`.
- `fragments_skipped` and `malformed_or_truncated`: packets excluded from payload inspection.

If needed, add `--all-udp` to print other inbound UDP payloads too. Display is capped at 256 bytes per datagram and control characters are escaped. The probe does not check IP/UDP checksums or authenticate its marker. Exit code `0` means the capture run finished normally, **even if zero markers were seen**; errors produce a nonzero exit code.

| Observation | Conclusion |
| --- | --- |
| Matching `MARKER` payloads and corresponding firewall `DROP UDP` records | The capture path can see blocked knocks under those test conditions. |
| Markers with no confirmation the firewall dropped them | Capture works, but visibility of blocked traffic remains unproven. |
| No markers, and firewall records show the probes arriving and being dropped | This mode did not deliver the blocked knock payloads in this configuration. |
| No markers and no evidence the probes reached the receiver | Inconclusive; check the address, adapter, sender, route, and upstream filtering. |
| `WSAEACCES` / error 10013 | Rerun in an elevated terminal. |
| Bind error 10049 | The address is not assigned to an active local interface. |
| `SIO_RCVALL` error | Record the complete message and whether `ip` or `on` was selected. |

For a stronger test, [temporarily block only the probe traffic and correlate firewall logs](firewall-test.md). Those are explicit manual steps with cleanup; the capture program itself never changes firewall policy.

## Report back

Send `capture-ip.txt`, `capture-on.txt`, the OS version/build, adapter type (Ethernet/Wi-Fi/VPN/VM), sender IP, and any matching firewall `DROP UDP` records. Include whether other security software was filtering traffic and any startup errors. Seeing all nine PowerShell probes is useful, but packet loss is possible; missing a probe is not by itself proof of a replay or capture bug.

## Build from source instead

With CMake and the Visual Studio C++ build tools, from the project root:

```powershell
cmake -S poc -B build\poc -A x64
cmake --build build\poc --config Release
.\build\poc\Release\raw-capture.exe 192.168.1.40 --seconds 60
```

Or directly from an **x64 Native Tools Command Prompt for Visual Studio**:

```bat
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT poc\raw_capture.cpp /Fe:raw-capture.exe /link Ws2_32.lib
```

The packaged executable is cross-compiled for Windows x64 using MinGW-w64, with the GCC C++ runtime statically linked; its imported DLLs are Windows components. Actual Windows capture behavior must be established by the tests above.

## References

- [Microsoft: SIO_RCVALL, capture modes, interface binding, and elevation](https://learn.microsoft.com/en-us/windows/win32/winsock/sio-rcvall)
- [Microsoft: raw sockets and firewall-related limitations](https://learn.microsoft.com/en-us/windows/win32/winsock/tcp-ip-raw-sockets-2)
- [Saved context for the larger SPA program](../docs/brainstorming-checkpoint.md)
