# Zeitgeist SPA brainstorming checkpoint

Saved 2026-11-17 before starting the explicitly authorized raw Winsock capture experiment.

## User intent and requirements

- Build a C++ program that broadens port knocking into Single Packet Authorization (SPA), bundling an authenticated request and its action parameters in the knock.
- Windows is the primary receiving platform.
- The receiver must observe traffic to arbitrary destination ports without binding a TCP or UDP listener. A raw socket bound to a local interface address is acceptable for the experiment.
- The user initially ruled out drivers, then explicitly accepted WinDivert's supplied signed driver. Developing our own driver remains outside the agreed approach.
- The user prefers avoiding wpcap because of licensing concerns.
- `-p <port>` should temporarily allow access from the requester's IP to that port.
- `-p a` should temporarily allow connections from that IP to any port.
- `-t <seconds>` should configure the access duration, defaulting to 30 seconds.
- Prefer a signal that can be sent with `nc`; a separate token generator or knocking binary is acceptable if necessary.
- Explore replay-resistant SPA while authenticating all requested commands and parameters.

## Discussion so far

- Passive packet capture can avoid a TCP/UDP listening port; it still only sees traffic that reaches the receiving host. Upstream firewalls and NAT remain relevant.
- Linux `AF_PACKET` was considered, but Linux is not the primary target.
- Windows supports raw IP sockets with Winsock `SIO_RCVALL`. They require elevation and an explicit local interface address. Binding that raw socket does not bind a TCP/UDP listening port.
- The decisive unresolved issue is whether the raw capture path delivers the full UDP payload when Windows Firewall is blocking that inbound traffic on the target Windows version.
- A custom WFP callout driver was described as another capture approach and ruled out. The user later proposed WinDivert and accepted its supplied signed driver instead.

## Proposed SPA ideas, not yet selected or approved

- Use an authenticated message containing command parameters, client identity, target identity, a timestamp, and a cryptographically random request ID.
- Check freshness and persist accepted request IDs to reject duplicates across service restarts. A timestamp alone leaves a replay window.
- `nc` can transport a generated token; it does not itself generate fresh cryptographic authentication.
- The cryptographic scheme, message format, key provisioning, source-IP binding, and firewall implementation have not been selected.

## Decisions still needed for the larger program

- Supported Windows versions; IPv4 and IPv6 scope; interface changes and multiple adapters.
- Capture architecture, contingent on the current experiment.
- Symmetric authentication versus public-key authorization; whether command confidentiality is required.
- Replay-cache persistence, crash consistency, retention, clock skew, and clock rollback behavior.
- Bind authorization to the sender's observed address versus an authenticated claimed address; NAT implications and captured-token forwarding/racing.
- Port protocol selection (TCP, UDP, or both), and the exact scope of `-p a`.
- Server-side per-key limits on ports, all-port access, duration, and action types.
- Whether expiry prevents new connections or also terminates established sessions.
- Temporary firewall grants, existing block-rule precedence, expiry after crashes, and restart cleanup.
- More actions should be explicit structured operations, with their authorization policy still to be designed.

## Authorized feasibility experiments

The user explicitly requested a small Windows raw Winsock capture POC and will run the Windows tests and report results. Preserve the broader discussion before coding. This is a spike, not the start of the production daemon.

The first experiment was a standalone elevated Winsock console capture probe, no driver, no transport listener, and instructions to send recognizable UDP payloads to unused arbitrary destination ports from a second machine. This is implemented and the first user results are recorded below.

The user subsequently accepted using WinDivert's supplied signed driver. The current task is a second small capture POC using passive, receive-only WinDivert network capture with the same UDP marker and test ports. Deliver source, a Windows x64 build with the official WinDivert runtime, and Windows test instructions. Keep both probes available for comparison. Preserve the broader SPA scope: this is still a feasibility experiment, not the production daemon.

Both probes should show source/destination addresses, ports, and payload so the result is assessable. Keep Windows Firewall enabled for the main experiment. Do not change firewall rules automatically. WinDivert's normal on-demand loading of its driver is now accepted.

Cross-compilation on the current Linux workspace can verify a Windows build, but it cannot establish actual Windows capture or firewall behavior. Report that distinction explicitly.

Once results arrive, return to the larger design discussion. No production design or implementation plan has been approved. The brainstorming workflow permits this explicitly requested spike without first approving the full design.

## First Windows test results supplied by the user

The user supplied two screenshots after running the packaged probe:

- OS: Microsoft Windows Server 2019 Standard, version `10.0.17763`, build `17763`.
- Interface: Ethernet, IPv4 `10.2.2.194`; active network category Private.
- Effective firewall profiles: Domain, Private, and Public are enabled with default inbound action Block.
- The probe ran from an Administrator PowerShell window, using `10.2.2.194` and 30 seconds per capture mode.

| Capture mode | Received | Inbound IPv4 | Complete UDP | Markers | Fragments skipped | Malformed/truncated |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `RCVALL_IPLEVEL` | 30 | 0 | 0 | 0 | 0 | 0 |
| `RCVALL_ON` | 28 | 0 | 0 | 0 | 0 | 0 |

The raw socket setup and receive loop succeeded in both modes. Reviewing `inspect_packet` shows that valid returned IPv4 packets with destinations other than the selected local address are excluded before incrementing `inbound_ipv4`. Thus these runs delivered packets, but none passed the destination-address filter; this was not merely a marker-string mismatch.

The user subsequently supplied the sender command from a Kali terminal:

```bash
for probe_port in 41001 42555 49999; do
    printf 'ZEITGEIST-POC: port=%s seq=1\n' "$probe_port" | nc -u -w 1 10.2.2.194 "$probe_port"
done
```

This matches the selected receiver address, intended UDP transport, three test ports, and expected marker prefix. No sender error is visible. UDP `nc` completing silently does not independently establish receiver-side arrival.

Working hypothesis: filtering may prevent inbound probe packets from reaching the raw socket. This is **not yet established**: no corresponding receiver firewall drop records or independent arrival evidence has been supplied. The experiment did not demonstrate the required blocked-payload visibility in this configuration; do not generalize these results to every Windows version or configuration. A matching `DROP UDP` record during capture would narrow the failure to raw-socket visibility of traffic that reached Windows and was blocked.

## WinDivert proposed by the user

The user asked for thoughts on WinDivert and suggested it may solve the capture issue. After the driver dependency was explained, the user answered "I think this is alright, yes" to using its supplied signed driver. It is selected for the next feasibility experiment; the production architecture remains unapproved.

- WinDivert exposes network-layer packet capture to a user-mode C/C++ application without requiring a TCP/UDP listener. Its network layer can deliver full packet data.
- A passive experiment would use `WINDIVERT_LAYER_NETWORK` with `WINDIVERT_FLAG_SNIFF | WINDIVERT_FLAG_RECV_ONLY` and an inbound UDP filter, initially restricted to the test receiver address. Sniff mode copies packets rather than requiring the application to reinject them.
- WinDivert **requires its kernel driver**. Official binary distributions include digitally signed driver files, and the library loads the driver on demand with administrator privileges. It avoids writing/signing our own driver; it does not remove the driver dependency.
- The earlier driver restriction is relaxed specifically for WinDivert's supplied signed driver. No custom kernel driver is planned. The agent works on Linux and will package the official files for the user's Windows test; it cannot establish Windows driver loading or capture behavior here.
- The author documents LGPLv3 usage for proprietary applications subject to the license terms and offers commercial licensing. Licensing concerns remain a deployment consideration.
- The next experiment is the same UDP payload test through WinDivert while confirming matching Windows Firewall drops. Do not promise blocked-packet visibility on this Server 2019 configuration before testing it.

The user has authorized the supplied WinDivert driver; do not ask for that approval again.

### Second POC implementation and handoff

- Implemented `poc/windivert_capture.cpp`: IPv4 inbound UDP capture to the supplied local address across all ports, `WINDIVERT_LAYER_NETWORK`, priority 0, `SNIFF | RECV_ONLY`, the same `ZEITGEIST-POC:` marker, source/destination/port/payload output, ten-second status updates, and a final summary.
- One outstanding overlapped receive permits an idle deadline and Ctrl+C without waiting for another packet. Pending reads are cancelled and completed before their buffers are released.
- Added optional `WINDIVERT_ROOT` support to the POC CMake project. It builds both probes and copies the official DLL/driver alongside the WinDivert executable; without that option, the Winsock-only build remains available.
- Downloaded the official `WinDivert-2.2.2-A.zip` release and upstream source at `v2.2.2`. Packaging includes the unmodified x64 runtime, original distribution, source archive, license, notices, and both probe sources/executables.
- The user-specific instructions are in `poc/windivert.md`, using receiver `10.2.2.194` and the original Kali sender command. The shared firewall logging/block test now also describes running the WinDivert probe.
- Both probes cross-compiled successfully in CMake Release with warnings treated as errors. PE/import checks confirm the WinDivert probe imports the official DLL and the overlapped cancellation API, with no `WinDivertSend` import. Bundled runtime files match the official archive byte-for-byte. The driver has an embedded certificate table; Windows trust acceptance has not been tested here.
- Handoff artifact: `dist/zeitgeist-windivert-poc.zip`. Windows driver loading, idle cancellation, and blocked-knock visibility still require the user's runtime test. No production authentication or firewall grants have been implemented.

## Primary references consulted

- [Microsoft: SIO_RCVALL](https://learn.microsoft.com/en-us/windows/win32/winsock/sio-rcvall)
- [Microsoft: raw socket behavior and limitations](https://learn.microsoft.com/en-us/windows/win32/winsock/tcp-ip-raw-sockets-2)
- [Microsoft: WFP architecture](https://learn.microsoft.com/en-us/windows/win32/fwp/windows-filtering-platform-architecture-overview)
- [Microsoft: Windows Firewall rule precedence](https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/rules)
- [fwknop: packet aging and persistent replay tracking](https://www.cipherdyne.com/fwknop/docs/manpages/fwknopd.html)
- [WinDivert: capture API, sniff mode, signed driver deployment](https://reqrypt.org/windivert-doc.html)
- [WinDivert: licensing and deployment FAQ](https://reqrypt.org/windivert-faq.html)
