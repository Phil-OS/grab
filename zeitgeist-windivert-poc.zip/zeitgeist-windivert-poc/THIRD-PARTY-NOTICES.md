# Third-party notices

The WinDivert POC package includes unmodified files from the official [WinDivert 2.2.2-A release](https://github.com/basil00/WinDivert/releases/tag/v2.2.2): `WinDivert.dll`, `WinDivert64.sys`, and the optional `windivertctl.exe` utility. The application links to the DLL dynamically. No WinDivert driver source was modified or rebuilt.

WinDivert is dual-licensed under LGPL version 3 or GPL version 2; this distribution uses the LGPLv3 option. The full upstream license and notices are preserved in [third_party/windivert/LICENSE](third_party/windivert/LICENSE).

The package includes:

- [Original official binary distribution](third_party/windivert/WinDivert-2.2.2-A.zip), including its public header, import libraries, documentation, and build version.
- [Upstream source at tag v2.2.2](third_party/windivert/WinDivert-2.2.2-source.tar.gz), including source and build scripts. Upstream source is also available from [the official repository](https://github.com/basil00/WinDivert/tree/v2.2.2).
- The probe source and rebuild instructions, allowing the application to be rebuilt against a compatible replacement WinDivert library.

WinDivert's supplied driver is loaded with Administrator privileges when the probe opens its capture handle. The library/driver remain independent of the still-undecided production SPA architecture. Consult the upstream license for its full terms.

The POC executables are cross-compiled with MinGW-w64 and the GCC C++ runtime, with the runtime linked statically under its runtime library exception. Those toolchain components are separate from WinDivert.
