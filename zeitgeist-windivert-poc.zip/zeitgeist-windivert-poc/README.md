# Zeitgeist

Windows-first C++ Single Packet Authorization exploration. The larger program is still being designed.

- [Saved brainstorming context and open decisions](docs/brainstorming-checkpoint.md)
- [WinDivert capture experiment and Windows test instructions](poc/windivert.md)
- [Raw Winsock capture experiment and Windows test instructions](poc/README.md)

The first probe uses built-in Winsock APIs. The second uses WinDivert's supplied signed driver, which the user has accepted. Both avoid a TCP/UDP listener and leave firewall rules unchanged. Authentication, replay protection, and temporary firewall grants remain part of the later design.

The WinDivert test package includes its runtime, upstream source, and [third-party license information](THIRD-PARTY-NOTICES.md).
