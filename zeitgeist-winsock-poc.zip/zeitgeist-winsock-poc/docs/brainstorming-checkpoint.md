# Zeitgeist SPA brainstorming checkpoint

Saved 2026-11-17 before starting the explicitly authorized raw Winsock capture experiment.

## User intent and requirements

- Build a C++ program that broadens port knocking into Single Packet Authorization (SPA), bundling an authenticated request and its action parameters in the knock.
- Windows is the primary receiving platform.
- The receiver must observe traffic to arbitrary destination ports without binding a TCP or UDP listener. A raw socket bound to a local interface address is acceptable for the experiment.
- A driver is **not acceptable**, including a custom WFP callout driver or a third-party capture driver.
- The user prefers avoiding wpcap because of licensing concerns.
- `-p <port>` should temporarily allow access from the requester's IP to that port.
- `-p a` should temporarily allow connections from that IP to any port.
- `-t <seconds>` should configure the access duration, defaulting to 30 seconds.
- Prefer a signal that can be sent with `nc`; a separate token generator or knocking binary is acceptable if necessary.
- Explore replay-resistant SPA while authenticating all requested commands and parameters.

## Discussion so far

- Passive packet capture can avoid a TCP/UDP listening port; it still only sees traffic that reaches the receiving host. Upstream firewalls and NAT remain relevant.
- Linux `AF_PACKET` was considered, but Linux is not the primary target.
- Windows supports raw IP sockets with Winsock `SIO_RCVALL`. They require elevation and an explicit local interface address. Binding that raw socket does not bind a TCP/UDP listening port.
- The decisive unresolved issue is whether the raw capture path delivers the full UDP payload when Windows Firewall is blocking that inbound traffic on the target Windows version.
- A WFP callout driver was described as another capture approach. The user has explicitly ruled drivers out; do not pursue that path.
- The user has an alternative idea if the raw socket experiment fails. Ask about that idea after obtaining the results rather than assuming the next capture architecture.

## Proposed SPA ideas, not yet selected or approved

- Use an authenticated message containing command parameters, client identity, target identity, a timestamp, and a cryptographically random request ID.
- Check freshness and persist accepted request IDs to reject duplicates across service restarts. A timestamp alone leaves a replay window.
- `nc` can transport a generated token; it does not itself generate fresh cryptographic authentication.
- The cryptographic scheme, message format, key provisioning, source-IP binding, and firewall implementation have not been selected.

## Decisions still needed for the larger program

- Supported Windows versions; IPv4 and IPv6 scope; interface changes and multiple adapters.
- Capture architecture, contingent on the current experiment.
- Symmetric authentication versus public-key authorization; whether command confidentiality is required.
- Replay-cache persistence, crash consistency, retention, clock skew, and clock rollback behavior.
- Bind authorization to the sender's observed address versus an authenticated claimed address; NAT implications and captured-token forwarding/racing.
- Port protocol selection (TCP, UDP, or both), and the exact scope of `-p a`.
- Server-side per-key limits on ports, all-port access, duration, and action types.
- Whether expiry prevents new connections or also terminates established sessions.
- Temporary firewall grants, existing block-rule precedence, expiry after crashes, and restart cleanup.
- More actions should be explicit structured operations, with their authorization policy still to be designed.

## Current authorized task: throwaway feasibility experiment

The user explicitly requested a small Windows raw Winsock capture POC and will run the Windows tests and report results. Preserve the broader discussion before coding. This is a spike, not the start of the production daemon.

Build a standalone elevated console capture probe, no driver, no transport listener, and instructions to send recognizable UDP payloads to unused arbitrary destination ports from a second machine. Show source/destination addresses, ports, and payload so the result is assessable. Keep Windows Firewall enabled for the main experiment. Do not change firewall settings automatically.

Cross-compilation on the current Linux workspace can verify a Windows build, but it cannot establish actual Windows capture or firewall behavior. Report that distinction explicitly.

Once results arrive, return to the larger design discussion. No production design or implementation plan has been approved. The brainstorming workflow permits this explicitly requested spike without first approving the full design.

## Primary references consulted

- [Microsoft: SIO_RCVALL](https://learn.microsoft.com/en-us/windows/win32/winsock/sio-rcvall)
- [Microsoft: raw socket behavior and limitations](https://learn.microsoft.com/en-us/windows/win32/winsock/tcp-ip-raw-sockets-2)
- [Microsoft: WFP architecture](https://learn.microsoft.com/en-us/windows/win32/fwp/windows-filtering-platform-architecture-overview)
- [Microsoft: Windows Firewall rule precedence](https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/rules)
- [fwknop: packet aging and persistent replay tracking](https://www.cipherdyne.com/fwknop/docs/manpages/fwknopd.html)
