# Zeitgeist

Windows-first C++ Single Packet Authorization exploration. The larger program is still being designed.

- [Saved brainstorming context and open decisions](docs/brainstorming-checkpoint.md)
- [Raw Winsock capture experiment and Windows test instructions](poc/README.md)

The current experiment uses built-in Winsock APIs, no additional driver, and no TCP/UDP listener. It does not implement authentication, replay protection, or temporary firewall grants.
