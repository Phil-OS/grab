param(
    [Parameter(Mandatory = $true)]
    [string]$Target,
    [ValidateRange(1, 65535)]
    [int[]]$Ports = @(41001, 42555, 49999),
    [ValidateRange(1, 10)]
    [int]$Count = 3
)

$ErrorActionPreference = 'Stop'
$targetAddress = [System.Net.IPAddress]::Parse($Target)
if ($targetAddress.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
    throw 'This probe uses IPv4. Supply the receiver adapter IPv4 address.'
}

$runId = [guid]::NewGuid().ToString('N')
$udp = New-Object System.Net.Sockets.UdpClient -ArgumentList ([System.Net.Sockets.AddressFamily]::InterNetwork)
try {
    Write-Output "Run id: $runId (sent does not mean delivered)"
    for ($sequence = 1; $sequence -le $Count; $sequence++) {
        foreach ($port in $Ports) {
            $message = "ZEITGEIST-POC: port=$port seq=$sequence id=$runId"
            $bytes = [System.Text.Encoding]::ASCII.GetBytes($message)
            $endpoint = New-Object System.Net.IPEndPoint -ArgumentList $targetAddress, $port
            $sent = $udp.Send($bytes, $bytes.Length, $endpoint)
            Write-Output "SENT ${Target}:$port bytes=$sent payload=$message"
            Start-Sleep -Milliseconds 250
        }
    }
}
finally {
    $udp.Dispose()
}
