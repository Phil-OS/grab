cmake_minimum_required(VERSION 3.15)
project(zeitgeist_raw_capture LANGUAGES CXX)

if(NOT WIN32)
    message(FATAL_ERROR "Use a Windows compiler or a Windows cross-compilation toolchain.")
endif()

add_executable(raw-capture raw_capture.cpp)
target_compile_features(raw-capture PRIVATE cxx_std_17)
target_link_libraries(raw-capture PRIVATE ws2_32)

if(MSVC)
    target_compile_options(raw-capture PRIVATE /W4 /WX /EHsc)
    set_property(TARGET raw-capture PROPERTY
        MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
elseif(MINGW)
    target_compile_options(raw-capture PRIVATE -Wall -Wextra -Wpedantic -Werror)
    target_link_options(raw-capture PRIVATE -static -static-libgcc -static-libstdc++)
endif()
