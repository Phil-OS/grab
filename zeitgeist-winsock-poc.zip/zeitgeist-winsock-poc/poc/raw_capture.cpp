// Throwaway IPv4 SIO_RCVALL feasibility probe. No TCP/UDP listener or firewall edits.
#ifndef _WIN32
#error This probe requires Windows and Winsock.
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <winsock2.h>
#include <ws2tcpip.h>
#include <mstcpip.h>
#include <windows.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>

namespace {
constexpr std::string_view marker = "ZEITGEIST-POC:";
volatile LONG stop_requested = FALSE;

BOOL WINAPI on_console_event(DWORD event) {
    if (event == CTRL_C_EVENT || event == CTRL_BREAK_EVENT) {
        InterlockedExchange(&stop_requested, TRUE);
        return TRUE;
    }
    return FALSE;
}

std::string winsock_error(const char* operation, int code) {
    char text[512]{};
    FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                   nullptr, static_cast<DWORD>(code), 0, text,
                   static_cast<DWORD>(sizeof(text)), nullptr);
    std::string description(text);
    while (!description.empty() &&
           (description.back() == '\r' || description.back() == '\n')) {
        description.pop_back();
    }
    std::string result = std::string(operation) + " failed: " +
                         std::to_string(code) + " " + description;
    if (code == WSAEACCES) {
        result += " (Run the terminal as Administrator.)";
    } else if (code == WSAEADDRNOTAVAIL) {
        result += " (Use this Windows machine's active adapter IPv4 address.)";
    }
    return result;
}

struct Winsock {
    Winsock() {
        WSADATA data{};
        const int result = WSAStartup(MAKEWORD(2, 2), &data);
        if (result != 0) {
            throw std::runtime_error(winsock_error("WSAStartup", result));
        }
    }
    ~Winsock() { WSACleanup(); }
    Winsock(const Winsock&) = delete;
    Winsock& operator=(const Winsock&) = delete;
};

struct RawSocket {
    SOCKET handle = INVALID_SOCKET;
    bool capture_enabled = false;

    RawSocket() {
        handle = socket(AF_INET, SOCK_RAW, IPPROTO_IP);
        if (handle == INVALID_SOCKET) {
            throw std::runtime_error(winsock_error("socket", WSAGetLastError()));
        }
    }
    ~RawSocket() {
        if (capture_enabled) {
            DWORD off = RCVALL_OFF;
            DWORD returned = 0;
            WSAIoctl(handle, SIO_RCVALL, &off, sizeof(off), nullptr, 0,
                     &returned, nullptr, nullptr);
        }
        closesocket(handle);
    }
    RawSocket(const RawSocket&) = delete;
    RawSocket& operator=(const RawSocket&) = delete;
};

struct Options {
    std::string interface_ip;
    int seconds = 60;
    DWORD mode = RCVALL_IPLEVEL;
    bool all_udp = false;
};

void usage() {
    std::cout <<
        "Usage: raw-capture.exe LOCAL_IPV4 [--seconds 60] [--mode ip|on] [--all-udp]\n"
        "Run as Administrator. LOCAL_IPV4 is an active adapter address, not 0.0.0.0.\n"
        "Default: RCVALL_IPLEVEL, IPv4 only, print inbound UDP starting with\n"
        "ZEITGEIST-POC:. --mode on selects RCVALL_ON (may enable promiscuous mode).\n"
        "--all-udp prints all complete inbound UDP payloads, up to 256 bytes each.\n"
        "No TCP/UDP port is bound. No firewall rules are changed. Ctrl+C stops.\n";
}

Options parse_options(int argc, char** argv) {
    Options options;
    options.interface_ip = argv[1];
    for (int index = 2; index < argc; ++index) {
        const std::string arg = argv[index];
        if (arg == "--all-udp") {
            options.all_udp = true;
        } else if ((arg == "--seconds" || arg == "--mode") && index + 1 < argc) {
            const std::string value = argv[++index];
            if (arg == "--mode") {
                if (value != "ip" && value != "on") {
                    throw std::invalid_argument("--mode must be ip or on");
                }
                options.mode = value == "ip" ? RCVALL_IPLEVEL : RCVALL_ON;
            } else {
                if (value.empty() || value.size() > 4 ||
                    value.find_first_not_of("0123456789") != std::string::npos) {
                    throw std::invalid_argument("--seconds must be 1 through 3600");
                }
                options.seconds = std::stoi(value);
                if (options.seconds < 1 || options.seconds > 3600) {
                    throw std::invalid_argument("--seconds must be 1 through 3600");
                }
            }
        } else {
            throw std::invalid_argument("Unknown option or missing value: " + arg);
        }
    }
    return options;
}

std::uint16_t read_u16(const unsigned char* bytes) {
    return static_cast<std::uint16_t>((static_cast<unsigned>(bytes[0]) << 8) |
                                      static_cast<unsigned>(bytes[1]));
}

std::string ipv4_text(const unsigned char* bytes) {
    return std::to_string(bytes[0]) + "." + std::to_string(bytes[1]) + "." +
           std::to_string(bytes[2]) + "." + std::to_string(bytes[3]);
}

std::string escaped_payload(std::string_view payload) {
    std::ostringstream output;
    const auto length = std::min<std::size_t>(payload.size(), 256);
    for (std::size_t index = 0; index < length; ++index) {
        const auto byte = static_cast<unsigned char>(payload[index]);
        if (byte == '\\' || byte == '"') {
            output << '\\' << static_cast<char>(byte);
        } else if (byte >= 32 && byte <= 126) {
            output << static_cast<char>(byte);
        } else {
            output << "\\x" << std::hex << std::setw(2) << std::setfill('0')
                   << static_cast<unsigned>(byte);
        }
    }
    if (length < payload.size()) {
        output << "... [display truncated]";
    }
    return output.str();
}

struct Counters {
    std::uint64_t received = 0;
    std::uint64_t inbound_ipv4 = 0;
    std::uint64_t complete_udp = 0;
    std::uint64_t markers = 0;
    std::uint64_t fragments = 0;
    std::uint64_t malformed = 0;
};

void print_stats(const Counters& counts, const char* label) {
    std::cout << label << " received=" << counts.received
              << " inbound_ipv4=" << counts.inbound_ipv4
              << " complete_udp=" << counts.complete_udp
              << " markers=" << counts.markers
              << " fragments_skipped=" << counts.fragments
              << " malformed_or_truncated=" << counts.malformed << '\n';
}

void inspect_packet(const unsigned char* packet, std::size_t size,
                    const sockaddr_in& local, const Options& options,
                    Counters& counts) {
    ++counts.received;
    if (size < 20 || (packet[0] >> 4) != 4) {
        ++counts.malformed;
        return;
    }
    const std::size_t header_size = (packet[0] & 0x0FU) * 4U;
    const std::size_t total_size = read_u16(packet + 2);
    if (header_size < 20 || total_size < header_size || total_size > size) {
        ++counts.malformed;
        return;
    }
    // Ignore outbound and other-address traffic. Interface capture includes both.
    const auto* local_bytes = reinterpret_cast<const unsigned char*>(&local.sin_addr);
    if (!std::equal(packet + 16, packet + 20, local_bytes)) {
        return;
    }
    ++counts.inbound_ipv4;
    if (packet[9] != IPPROTO_UDP) {
        return;
    }
    // A tiny probe should not require IP fragmentation or reassembly.
    if ((read_u16(packet + 6) & 0x3FFFU) != 0) {
        ++counts.fragments;
        return;
    }
    if (total_size - header_size < 8) {
        ++counts.malformed;
        return;
    }
    const auto* udp = packet + header_size;
    const std::size_t udp_size = read_u16(udp + 4);
    if (udp_size < 8 || udp_size > total_size - header_size) {
        ++counts.malformed;
        return;
    }
    ++counts.complete_udp;
    const std::string_view payload(reinterpret_cast<const char*>(udp + 8), udp_size - 8);
    const bool matched = payload.size() >= marker.size() &&
                         payload.substr(0, marker.size()) == marker;
    if (matched) {
        ++counts.markers;
    }
    if (matched || options.all_udp) {
        std::cout << (matched ? "MARKER " : "UDP ")
                  << ipv4_text(packet + 12) << ':' << read_u16(udp)
                  << " -> " << ipv4_text(packet + 16) << ':' << read_u16(udp + 2)
                  << " bytes=" << payload.size() << " payload=\""
                  << escaped_payload(payload) << "\"\n";
    }
}

int capture(const Options& options) {
    Winsock runtime;
    sockaddr_in local{};
    local.sin_family = AF_INET;
    local.sin_port = 0; // Raw interface binding; this allocates no TCP/UDP port.
    if (InetPtonA(AF_INET, options.interface_ip.c_str(), &local.sin_addr) != 1 ||
        local.sin_addr.s_addr == INADDR_ANY ||
        local.sin_addr.s_addr == INADDR_BROADCAST) {
        throw std::invalid_argument("Specify an active adapter's unicast IPv4 address");
    }
    RawSocket raw;
    if (bind(raw.handle, reinterpret_cast<const sockaddr*>(&local), sizeof(local)) ==
        SOCKET_ERROR) {
        throw std::runtime_error(winsock_error("bind", WSAGetLastError()));
    }
    DWORD mode = options.mode;
    DWORD returned = 0;
    if (WSAIoctl(raw.handle, SIO_RCVALL, &mode, sizeof(mode), nullptr, 0,
                 &returned, nullptr, nullptr) == SOCKET_ERROR) {
        throw std::runtime_error(winsock_error("SIO_RCVALL", WSAGetLastError()));
    }
    raw.capture_enabled = true;
    std::cout << "Zeitgeist raw Winsock probe v1 (IPv4 only)\n"
              << "Interface=" << options.interface_ip << " mode="
              << (mode == RCVALL_IPLEVEL ? "RCVALL_IPLEVEL" : "RCVALL_ON")
              << " seconds=" << options.seconds << '\n'
              << "READY: send UDP payloads beginning ZEITGEIST-POC: from ANOTHER machine\n"
              << "to this interface IP and any destination port. No TCP/UDP listener.\n"
              << "Firewall configuration is unchanged. Ctrl+C stops.\n";

    std::array<unsigned char, 65536> buffer{};
    Counters counts;
    using Clock = std::chrono::steady_clock;
    const auto end = Clock::now() + std::chrono::seconds(options.seconds);
    auto next_status = Clock::now() + std::chrono::seconds(10);
    int exit_code = 0;
    while (InterlockedCompareExchange(&stop_requested, FALSE, FALSE) == FALSE &&
           Clock::now() < end) {
        fd_set ready;
        FD_ZERO(&ready);
        FD_SET(raw.handle, &ready);
        timeval wait{0, 250000};
        const int selected = select(0, &ready, nullptr, nullptr, &wait);
        if (selected == SOCKET_ERROR) {
            std::cerr << winsock_error("select", WSAGetLastError()) << '\n';
            exit_code = 1;
            break;
        }
        if (selected > 0) {
            const int size = recv(raw.handle, reinterpret_cast<char*>(buffer.data()),
                                  static_cast<int>(buffer.size()), 0);
            if (size == SOCKET_ERROR) {
                std::cerr << winsock_error("recv", WSAGetLastError()) << '\n';
                exit_code = 1;
                break;
            }
            inspect_packet(buffer.data(), static_cast<std::size_t>(size),
                           local, options, counts);
        }
        if (Clock::now() >= next_status) {
            print_stats(counts, "STATUS");
            next_status = Clock::now() + std::chrono::seconds(10);
        }
    }
    print_stats(counts, "SUMMARY");
    std::cout << "Marker presence shows capture visibility; it does not prove firewall\n"
              << "blocking. Correlate with the firewall log and your test conditions.\n";
    return exit_code;
}
} // namespace

int main(int argc, char** argv) {
    std::cout << std::unitbuf;
    if (argc < 2 || std::string_view(argv[1]) == "--help" ||
        std::string_view(argv[1]) == "-h") {
        usage();
        return argc < 2 ? 2 : 0;
    }
    try {
        const auto options = parse_options(argc, argv);
        if (!SetConsoleCtrlHandler(on_console_event, TRUE)) {
            throw std::runtime_error("Could not install Ctrl+C handler");
        }
        return capture(options);
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 1;
    }
}
