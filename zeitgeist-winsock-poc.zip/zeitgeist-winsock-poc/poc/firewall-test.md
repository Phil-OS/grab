# Optional: confirm visibility of explicitly blocked probes

Use this after the initial capture runs if you want a stronger result. Keep the firewall enabled throughout. These commands manually add one narrowly scoped block rule and enable dropped-packet logging; they are not run by the program.

Run the following in an elevated PowerShell window on the **receiver**, and keep that window open until cleanup. Replace the example addresses with the receiver and sender LAN IPv4 addresses. If the sender is behind NAT, use the source address that the receiver actually sees.

## Set up a scoped block

```powershell
$probeSender = '192.168.1.41'
$probeReceiver = '192.168.1.40'
$probePorts = @(41001, 42555, 49999)
$probeRule = 'Zeitgeist-POC-' + [guid]::NewGuid().ToString('N')
$probeLoggingBefore = @(Get-NetFirewallProfile -PolicyStore PersistentStore | Select-Object Name, LogBlocked)

New-NetFirewallRule -Name $probeRule -DisplayName 'Zeitgeist POC temporary UDP block' -Direction Inbound -Action Block -Protocol UDP -LocalAddress $probeReceiver -LocalPort $probePorts -RemoteAddress $probeSender -Profile Any
Set-NetFirewallProfile -Name Domain, Private, Public -LogBlocked True
Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name, Enabled, LogBlocked, LogFileName
```

The block affects only UDP from that sender to those three ports on that receiver address. It deliberately takes precedence over ordinary conflicting allow rules. Domain policy or third-party filtering can affect the result; record those conditions rather than changing broader policy.

## Run each capture mode and send again

In another elevated receiver window, run each capture mode separately and send the probes from the second machine after each `READY`:

```powershell
.\dist\raw-capture.exe 192.168.1.40 --seconds 60 --mode ip | Tee-Object capture-blocked-ip.txt
.\dist\raw-capture.exe 192.168.1.40 --seconds 60 --mode on | Tee-Object capture-blocked-on.txt
```

After each run, inspect the log path reported by `LogFileName`. If the default path is in use:

```powershell
Get-Content "$env:SystemRoot\System32\LogFiles\Firewall\pfirewall.log" -Tail 100
```

Allow a few seconds for logs to flush. Look for `DROP UDP` records with the sender/receiver addresses and destination ports `41001`, `42555`, or `49999` at the test time. Match source ports too when available. If profile-specific paths are configured, inspect those paths instead; `%systemroot%` in a reported path means the Windows directory.

The important result is whether a `MARKER` line with the full test payload appears **while a corresponding drop is confirmed**. A missing log entry is not proof that the packet was allowed or never arrived.

## Cleanup in the original PowerShell window

```powershell
Get-NetFirewallRule -Name $probeRule -ErrorAction SilentlyContinue | Remove-NetFirewallRule
foreach ($profile in $probeLoggingBefore) {
    Set-NetFirewallProfile -Name $profile.Name -LogBlocked $profile.LogBlocked
}
```

If that window was closed, find the specific rule with `Get-NetFirewallRule -DisplayName 'Zeitgeist POC temporary UDP block'`, remove the matching POC rule, and restore logging using the settings you recorded. Removing the rule returns those ports to their previous policy; it does not create an allow rule.

References: [Windows Firewall rule precedence](https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/rules), [Set-NetFirewallProfile](https://learn.microsoft.com/en-us/powershell/module/netsecurity/set-netfirewallprofile), [New-NetFirewallRule](https://learn.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule).
